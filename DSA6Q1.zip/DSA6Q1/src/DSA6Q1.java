import java.util.Arrays;
public class DSA6Q1 {
	 public static int[] reconstructPermutation(String s) {
	        int n = s.length();
	        int[] perm = new int[n + 1];
	        int low = 0;
	        int high = n;

	        for (int i = 0; i < n; i++) {
	            if (s.charAt(i) == 'I') {
	                perm[i] = low;
	                low++;
	            } else if (s.charAt(i) == 'D') {
	                perm[i] = high;
	                high--;
	            }
	        }

	        perm[n] = low;

	        return perm;
	    }

	public static void main(String[] args) {
		 String s = "IDID";
	        int[] perm = reconstructPermutation(s);
	        System.out.println(Arrays.toString(perm));
	}

}




