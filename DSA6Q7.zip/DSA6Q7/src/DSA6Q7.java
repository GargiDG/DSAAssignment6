
public class DSA6Q7 {
	 public static int[][] generateMatrix(int n) {
	        int[][] matrix = new int[n][n];
	        int startRow = 0, endRow = n - 1;
	        int startCol = 0, endCol = n - 1;
	        int num = 1;

	        while (startRow <= endRow && startCol <= endCol) {
	            // Traverse top row
	            for (int col = startCol; col <= endCol; col++) {
	                matrix[startRow][col] = num++;
	            }
	            startRow++;

	            // Traverse rightmost column
	            for (int row = startRow; row <= endRow; row++) {
	                matrix[row][endCol] = num++;
	            }
	            endCol--;

	            // Traverse bottom row
	            if (startRow <= endRow) {
	                for (int col = endCol; col >= startCol; col--) {
	                    matrix[endRow][col] = num++;
	                }
	                endRow--;
	            }

	            // Traverse leftmost column
	            if (startCol <= endCol) {
	                for (int row = endRow; row >= startRow; row--) {
	                    matrix[row][startCol] = num++;
	                }
	                startCol++;
	            }
	        }

	        return matrix;
	    }
	public static void main(String[] args) {
		int n = 3;
        int[][] result = generateMatrix(n);

        // Print the matrix
        for (int[] row : result) {
            for (int num : row) {
                System.out.print(num + " ");
            }
            System.out.println();
        }	

	}

} 